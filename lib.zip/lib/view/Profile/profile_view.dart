import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:study_side/services/firestore_services.dart';
import 'package:study_side/services/progress_service.dart';
import 'package:study_side/theme/app_theme.dart';
import 'package:study_side/view_model/Progress/progress_view_model.dart';



class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [

        ChangeNotifierProvider(
          create: (_) => ProfileViewModel(
            firestoreService:
            FirestoreService(),
          )..loadProfile(),
        ),

        ChangeNotifierProvider(
          create: (_) => ProgressViewModel(
            firestoreService:
            FirestoreService(),
          )..startListening(),
        ),
      ],

      child: const _ProfileBody(),
    );
  }
}

class _ProfileBody extends StatelessWidget {
  const _ProfileBody();

  @override
  Widget build(BuildContext context) {

    final profileVM =
    context.watch<ProfileViewModel>();

    final progressVM =
    context.watch<ProgressViewModel>();

    final profile =
        profileVM.profile;

    final progress =
        progressVM.progress;

    return Scaffold(
      backgroundColor:
      const Color(0xffF9F8FE),

      body: SafeArea(
        child: SingleChildScrollView(
          padding:
          const EdgeInsets.fromLTRB(
            20,
            20,
            20,
            30,
          ),
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [

              // HEADER
              Row(
                mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
                children: [

                  const Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [

                      Text(
                        'Profile',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight:
                          FontWeight.bold,
                          color:
                          AppColors.textDark,
                        ),
                      ),

                      SizedBox(height: 5),

                      Text(
                        'Manage your account and settings',
                        style: TextStyle(
                          fontSize: 13,
                          color:
                          AppColors.textGrey,
                        ),
                      ),
                    ],
                  ),

                  IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.settings_outlined,
                      color:
                      AppColors.primary,
                      size: 28,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // USER CARD
              Container(
                width: double.infinity,
                padding:
                const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                  BorderRadius.circular(18),
                  boxShadow: cardShadow,
                ),
                child: Row(
                  children: [

                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color:
                        const Color(0xffDDD1FA),
                        borderRadius:
                        BorderRadius.circular(22),
                      ),
                      child: const Icon(
                        Icons.person,
                        size: 52,
                        color:
                        AppColors.primary,
                      ),
                    ),

                    const SizedBox(width: 15),

                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [

                          Text(
                            profile.name,
                            style: const TextStyle(
                              fontSize: 19,
                              fontWeight:
                              FontWeight.bold,
                              color:
                              AppColors.textDark,
                            ),
                          ),

                          const SizedBox(height: 5),

                          Text(
                            profile.email,
                            style: const TextStyle(
                              fontSize: 12,
                              color:
                              AppColors.textGrey,
                            ),
                            overflow:
                            TextOverflow.ellipsis,
                          ),

                          const SizedBox(height: 8),

                          Container(
                            padding:
                            const EdgeInsets
                                .symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration:
                            BoxDecoration(
                              color:
                              const Color(
                                0xffF0EAFE,
                              ),
                              borderRadius:
                              BorderRadius.circular(
                                20,
                              ),
                            ),
                            child: Text(
                              profile.role,
                              style:
                              const TextStyle(
                                fontSize: 11,
                                fontWeight:
                                FontWeight.bold,
                                color:
                                AppColors.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    IconButton(
                      onPressed: () {
                        _editName(
                          context,
                          profileVM,
                          profile.name,
                        );
                      },
                      icon: const Icon(
                        Icons.edit_outlined,
                        color:
                        AppColors.primary,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // STATISTICS
              Container(
                width: double.infinity,
                padding:
                const EdgeInsets.symmetric(
                  vertical: 18,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                  BorderRadius.circular(18),
                  boxShadow: cardShadow,
                ),
                child: Row(
                  children: [

                    Expanded(
                      child: _ProfileStat(
                        icon:
                        Icons.access_time,
                        value:
                        progressVM.formatTime(
                          progress.totalStudyMinutes,
                        ),
                        label:
                        'Total Study Time',
                      ),
                    ),

                    _divider(),

                    Expanded(
                      child: _ProfileStat(
                        icon:
                        Icons.local_fire_department,
                        value:
                        '${progress.currentStreak}',
                        label:
                        'Current Streak',
                      ),
                    ),

                    _divider(),

                    Expanded(
                      child: _ProfileStat(
                        icon:
                        Icons.check_circle_outline,
                        value:
                        '${progress.sessions}',
                        label:
                        'Sessions',
                      ),
                    ),

                    _divider(),

                    Expanded(
                      child: _ProfileStat(
                        icon:
                        Icons.emoji_events_outlined,
                        value:
                        '${progress.goalsCompleted}/10',
                        label:
                        'Goals Completed',
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // FREE PLAN
              Container(
                width: double.infinity,
                padding:
                const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  color:
                  const Color(0xffF0EAFE),
                  borderRadius:
                  BorderRadius.circular(18),
                ),
                child: Row(
                  children: [

                    Container(
                      width: 48,
                      height: 48,
                      decoration:
                      const BoxDecoration(
                        color:
                        AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.workspace_premium,
                        color: Colors.white,
                      ),
                    ),

                    const SizedBox(width: 12),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [

                          Text(
                            'You\'re on Free Plan',
                            style: TextStyle(
                              fontWeight:
                              FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),

                          SizedBox(height: 4),

                          Text(
                            'Upgrade to Premium for more features and a better experience',
                            style: TextStyle(
                              fontSize: 10,
                              color:
                              AppColors.textGrey,
                            ),
                          ),
                        ],
                      ),
                    ),

                    ElevatedButton(
                      onPressed: () {},
                      style:
                      ElevatedButton.styleFrom(
                        backgroundColor:
                        AppColors.primary,
                        foregroundColor:
                        Colors.white,
                        elevation: 0,
                      ),
                      child: const Text(
                        'Upgrade Now',
                        style: TextStyle(
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // MENU
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                  BorderRadius.circular(18),
                  boxShadow: cardShadow,
                ),
                child: Column(
                  children: [

                    _MenuItem(
                      icon:
                      Icons.person_outline,
                      title: 'Edit Profile',
                      onTap: () {
                        _editName(
                          context,
                          profileVM,
                          profile.name,
                        );
                      },
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.track_changes_outlined,
                      title: 'Study Goals',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.notifications_none,
                      title: 'Notifications',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.access_time,
                      title: 'Study Reminders',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.palette_outlined,
                      title: 'Theme',
                      trailing: 'Light',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon: Icons.language,
                      title: 'Language',
                      trailing: 'English',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.help_outline,
                      title: 'Help & Support',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.info_outline,
                      title: 'About StudyRoom',
                      onTap: () {},
                    ),

                    _MenuDivider(),

                    _MenuItem(
                      icon:
                      Icons.logout_outlined,
                      title: 'Log Out',
                      logout: true,
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _divider() {
    return Container(
      width: 1,
      height: 55,
      color: const Color(0xffEEEEEE),
    );
  }

  static Future<void> _editName(
      BuildContext context,
      ProfileViewModel vm,
      String oldName,
      ) async {

    final controller =
    TextEditingController(
      text: oldName,
    );

    await showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          title:
          const Text('Edit Profile'),

          content: TextField(
            controller: controller,
            decoration:
            const InputDecoration(
              labelText: 'Name',
              border:
              OutlineInputBorder(),
            ),
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child:
              const Text('Cancel'),
            ),

            ElevatedButton(
              onPressed: () async {

                if (controller.text
                    .trim()
                    .isEmpty) {
                  return;
                }

                await vm.updateName(
                  controller.text.trim(),
                );

                if (context.mounted) {
                  Navigator.pop(context);
                }
              },
              child:
              const Text('Save'),
            ),
          ],
        );
      },
    );

    controller.dispose();
  }
}

// ======================================================

class _ProfileStat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _ProfileStat({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        Icon(
          icon,
          color: AppColors.primary,
          size: 23,
        ),

        const SizedBox(height: 7),

        Text(
          value,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 14,
            fontWeight:
            FontWeight.bold,
          ),
        ),

        const SizedBox(height: 3),

        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 8,
            color:
            AppColors.textGrey,
          ),
        ),
      ],
    );
  }
}

// ======================================================

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final bool logout;
  final VoidCallback onTap;

  const _MenuItem({
    required this.icon,
    required this.title,
    required this.onTap,
    this.trailing,
    this.logout = false,
  });

  @override
  Widget build(BuildContext context) {

    final itemColor = logout
        ? const Color(0xffD95F6B)
        : AppColors.textDark;

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 12,
        ),
        child: Row(
          children: [

            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: logout
                    ? const Color(0xffffeeee)
                    : const Color(0xffF2EEFC),
                borderRadius:
                BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: logout
                    ? const Color(0xffD95F6B)
                    : AppColors.primary,
                size: 21,
              ),
            ),

            const SizedBox(width: 13),

            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  color: itemColor,
                  fontWeight:
                  FontWeight.w500,
                ),
              ),
            ),

            if (trailing != null)
              Container(
                padding:
                const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color:
                  const Color(0xffF2EEFC),
                  borderRadius:
                  BorderRadius.circular(10),
                ),
                child: Text(
                  trailing!,
                  style: const TextStyle(
                    fontSize: 10,
                    color:
                    AppColors.primary,
                  ),
                ),
              ),

            const SizedBox(width: 5),

            Icon(
              Icons.chevron_right,
              color: logout
                  ? const Color(0xffD95F6B)
                  : AppColors.textGrey,
            ),
          ],
        ),
      ),
    );
  }
}

// ======================================================

class _MenuDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Divider(
      height: 1,
      indent: 68,
      endIndent: 15,
      color: Color(0xffEEEEEE),
    );
  }
}